def basic(martix):
    row = len(martix)
    cols = len(martix[0])
    return row,cols


def chengji(martix,martix2):
     row,cols = basic(martix)
     row2,cols2 = basic(martix2)
     ans_martix = [[0 for _ in range(cols2)] for _ in range(row)]
     if cols == row2:
         for i in range(row):
             for j in range(cols2):
                 for k in range(row2):
                    ans_martix[i][j] += martix[i][k]*martix2[k][j]
     else:
         ans = "Wrong Input for normal!"
         print(ans)
         return " "
     return ans_martix
 
def hadamn(martix,martix2):
     row,cols = basic(martix)
     row2,cols2 = basic(martix2)
     ans_martix = [[0 for _ in range(cols2)] for _ in range(row)]
     if cols == cols2 and row == row2:
         for i in range(row):
             for j in range(cols):
                 ans_martix[i][j] = martix[i][j] * martix2[i][j]
     else:
         ans = "Wrong Input for hadamn!"
         print(ans)
         return " "
     return ans_martix
 
def change(martix):
     rows,cols = basic(martix)
     ans_martix = [[0 for _ in range(rows)] for _ in range(cols)]
     for i in range(rows):
         for j in range(cols):
             ans_martix[j][i] = martix[i][j]
     return ans_martix
 
def print1(matrix, file=None):
    row, col = basic(matrix)
    for i in range(row):
        line = ""
        for j in range(col):
            line += f"{matrix[i][j]} "
        print(line)
        if file:
            print(line, file=file)
    print("")
    if file:
        print("", file=file)

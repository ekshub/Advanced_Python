import numpy as np # 导入numpy工具包
F = np.array([ # 创建ndarray类对象F（对应一个3*3矩阵，待做卷积计算的二维数据）
    [1, 2, -1],
    [-2, -3, -4],
    [3, 4, 5]
])

C = np.array([ # 创建ndarray类对象C（对应一个2*2矩阵，卷积核）
    [0.3, 0.1],
    [0.2, 0.4]
])

R = np.zeros((2, 2)) # 创建2行*2列，所有元素值都为零的ndarray类对象
for row in range(2): # 依次获取切片操作的起始行索引
    for col in range(2): # 依次获取切片操作的起始列索引
        R[row, col] = np.sum(F[row:row+2, col:col+2]*C) # 先对F切片操作得到2行*2列元素并将切片结果与C做哈达玛积，再调用np.sum函数计算哈达玛积结果矩阵的元素之和，最后将求得的和保存到结果矩阵相应位置
print("卷积结果：\n", R)
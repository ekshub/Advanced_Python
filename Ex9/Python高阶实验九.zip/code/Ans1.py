import numpy as np  

class Convolution:
    def __init__(self, input_shape, kernel_shape, num_channels, num_kernels):
        self.input_shape = input_shape
        self.kernel_shape = kernel_shape
        self.num_channels = num_channels
        self.num_kernels = num_kernels
        self.F = None
        self.kernels = None
        self.output = None
        self.result_sum = None

    def initialize_data(self):
        self.F = np.random.uniform(-10, 10, (self.num_channels, *self.input_shape))
        self.kernels = np.random.uniform(-10, 10, (self.num_kernels, self.num_channels, *self.kernel_shape))
        print("运算数据F：\n", self.F)
        print("\n卷积核：\n", self.kernels)

    def compute_output_shape(self):
        output_shape = (self.input_shape[0] - self.kernel_shape[0] + 1, self.input_shape[1] - self.kernel_shape[1] + 1)
        return output_shape

    def perform_convolution(self):
        output_shape = self.compute_output_shape()
        self.output = np.zeros((self.num_kernels, *output_shape))

        for k in range(self.num_kernels):  
            for row in range(output_shape[0]):
                for col in range(output_shape[1]):
                    conv_sum = 0
                    for c in range(self.num_channels):
                        conv_sum += np.sum(self.F[c, row:row+self.kernel_shape[0], col:col+self.kernel_shape[1]] * self.kernels[k, c])
                    self.output[k, row, col] = conv_sum  

        self.result_sum = np.sum(self.output, axis=0)
        return self.output, self.result_sum

    def display_results(self):
        print("\n各通道卷积结果：\n", self.output)
        print("\n卷积结果总和：\n", self.result_sum)

    def reset(self):

        self.F = None
        self.kernels = None
        self.output = None
        self.result_sum = None


input_shape = (3, 3)
kernel_shape = (2, 2)
num_channels = 3
num_kernels = 2

conv = Convolution(input_shape, kernel_shape, num_channels, num_kernels)
conv.initialize_data()
conv.perform_convolution()
conv.display_results()

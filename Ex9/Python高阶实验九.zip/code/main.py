import re
import json
import os
import hashlib

class User:
    def __init__(self, username, email, password):
        self.username = username
        self.email = email
        self.password = password

class RegistrationSystem:
    def __init__(self, data_file='users.json'):
        self.users = {} 
        self.data_file = data_file
        self.load_users()
        self.current_user = None

    def load_users(self):

        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for username, info in data.items():
                        user = User(username, info['email'], info['password'])
                        self.users[username] = user
            except (IOError, json.JSONDecodeError) as e:
                print(f"加载用户数据时出错：{e}")
        else:
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump({}, f)

    def save_users(self):

        data = {}
        for username, user in self.users.items():
            data[username] = {
                'email': user.email,
                'password': user.password
            }
        try:
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
        except IOError as e:
            print(f"保存用户数据时出错：{e}")

    def is_username_taken(self, username):
        return username in self.users

    def is_email_taken(self, email):
        for user in self.users.values():
            if user.email == email:
                return True
        return False

    def validate_email(self, email):
        email_regex = r'^[\w\.-]+@[\w\.-]+\.\w+$'
        if re.match(email_regex, email):
            return True
        else:
            print("电子邮件格式不正确，请重新输入。")
            return False

    def validate_password(self, password):
        password_regex = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$'
        if re.match(password_regex, password):
            return True
        else:
            print("密码必须至少包含8个字符，且至少包含一个大写字母、一个小写字母、一个数字和一个特殊字符（@$!%*?&）。")
            return False

    def hash_password(self, password):

        return hashlib.sha256(password.encode('utf-8')).hexdigest()

    def register_user(self):
        while True:
            username = input("请输入用户名：")
            if self.is_username_taken(username):
                print("用户名已存在，请重新输入。")
                continue
            email = input("请输入电子邮件：")
            if self.is_email_taken(email):
                print("该电子邮件已被注册，请使用其他电子邮件。")
                continue
            if not self.validate_email(email):
                continue
            password = input("请输入密码：")
            if not self.validate_password(password):
                continue

            hashed_password = self.hash_password(password)
            user = User(username, email, hashed_password)
            self.users[username] = user
            self.save_users()
            print("用户注册成功！")
            break

    def login_user(self):
        username = input("请输入用户名：")
        if not self.is_username_taken(username):
            print("用户名不存在，请先注册。")
            return False

        password = input("请输入密码：")
        hashed_password = self.hash_password(password)
        if self.users[username].password == hashed_password:
            print("登录成功！")
            self.current_user = username
            return True
        else:
            print("密码错误，请重试。")
            return False

    def delete_user(self):

        if self.current_user is None:
            print("当前没有用户登录。")
            return

        username = self.current_user
        password = input(f"{username}, 请输入密码确认：")
        hashed_password = self.hash_password(password)
        if self.users[username].password == hashed_password:
            del self.users[username]
            self.save_users()
            print(f"用户 {username} 已成功注销！")
            self.current_user = None
        else:
            print("密码错误，无法注销用户。")


def main():
    system = RegistrationSystem()
    while True:
        if system.current_user:
            print(f"\n===== 用户系统（当前用户：{system.current_user}） =====")
        else:
            print("\n===== 用户系统 =====")
        print("1. 注册新用户")
        print("2. 用户登录")
        print("3. 注销用户")
        print("4. 退出")
        choice = input("请选择操作（1/2/3/4）：")
        if choice == '1':
            system.register_user()
        elif choice == '2':
            system.login_user()
        elif choice == '3':
            system.delete_user()
        elif choice == '4':
            print("感谢使用，程序已退出。")
            break
        else:
            print("无效的选择，请重新输入。")

if __name__ == "__main__":
    main()

from data_provider.data_loader import Dataset_ETT_hour, Dataset_ETT_minute, Dataset_Custom, Dataset_Pred
import mindspore.dataset as ds
import numpy as np
data_dict = {
    'ETTh1': Dataset_ETT_hour,
    'ETTh2': Dataset_ETT_hour,
    'ETTm1': Dataset_ETT_minute,
    'ETTm2': Dataset_ETT_minute,
    'custom': Dataset_Custom,
}

def get_numpy_data(args, flag):
    Data = data_dict[args.data]
    timeenc = 0 

    if flag == 'test':
        shuffle_flag = False
        drop_last = False  # 修复错误
        batch_size = args.batch_size
        freq = args.freq
    elif flag == 'pred':
        shuffle_flag = False
        drop_last = False
        batch_size = 1
        freq = args.freq
        Data = Dataset_Pred
    else:
        shuffle_flag = True
        drop_last = True
        batch_size = args.batch_size
        freq = args.freq

    # 初始化自定义数据集
    data_set = Data(
        root_path=args.root_path,
        data_path=args.data_path,
        flag=flag,
        size=[args.seq_len, args.label_len, args.pred_len],
        features=args.features,
        target=args.target,
        timeenc=timeenc,
        freq=freq
    )

    # 将所有样本收集到 NumPy 数组中
    all_data = [data_set[i] for i in range(len(data_set))]
    batch_x = np.array([item[0] for item in all_data])
    batch_y = np.array([item[1] for item in all_data])
    batch_x_mark = np.array([item[2] for item in all_data])
    batch_y_mark = np.array([item[3] for item in all_data])

    # 创建 NumpySlicesDataset
    dataset = ds.NumpySlicesDataset(
        {"batch_x": batch_x, "batch_y": batch_y, "batch_x_mark": batch_x_mark, "batch_y_mark": batch_y_mark},
        shuffle=shuffle_flag
    ).batch(batch_size, drop_remainder=drop_last)

    return data_set, dataset



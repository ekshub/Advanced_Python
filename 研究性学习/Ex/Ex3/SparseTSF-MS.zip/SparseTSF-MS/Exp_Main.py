import numpy as np
import mindspore as ms
from data_provider.data_factory import get_numpy_data
from mindspore import nn,context

from utils.tools import EarlyStopping
import time
from models.SparseTSF import SparseTSF,MyWithLossCell
import os 
# 设置MindSpore的运行模式为动态图模式，便于调试
ms.context.set_context(mode=ms.context.PYNATIVE_MODE)

class Exp_Main:
    def __init__(self, args):
        self.configs=args
        self.model = SparseTSF(self.configs)
        self.set_random_seed(args.seed) 

        # 定义损失函数和优化器
        self.criterion = nn.MSELoss()

        self.optimizer = nn.Adam(self.model.trainable_params(), learning_rate=self.configs.learning_rate)

        # 将模型和损失函数封装到 WithLossCell 中
    
        self.net_with_loss = MyWithLossCell(self.model, self.criterion, self.configs)

        # 使用 TrainOneStepCell 封装网络和优化器
        self.train_network = nn.TrainOneStepCell(self.net_with_loss, self.optimizer)
    def adjust_learning_rate(self, epoch):
        """根据当前的 epoch 调整学习率"""
        if self.configs.lradj == 'type1':
            lr_adjust = {epoch: self.configs.learning_rate * (0.5 ** ((epoch - 1) // 1))}
        elif self.configs.lradj == 'type2':
            lr_adjust = {
                2: 5e-5, 4: 1e-5, 6: 5e-6, 8: 1e-6,
                10: 5e-7, 15: 1e-7, 20: 5e-8
            }
        elif self.configs.lradj == 'type3':
            lr_adjust = {epoch: self.configs.learning_rate if epoch < 3 else self.configs.learning_rate * (0.8 ** ((epoch - 3) // 1))}
        elif self.configs.lradj == 'constant':
            lr_adjust = {epoch: self.configs.learning_rate}
        elif self.configs.lradj == '3':
            lr_adjust = {epoch: self.configs.learning_rate if epoch < 10 else self.configs.learning_rate * 0.1}
        elif self.configs.lradj == '4':
            lr_adjust = {epoch: self.configs.learning_rate if epoch < 15 else self.configs.learning_rate * 0.1}
        elif self.configs.lradj == '5':
            lr_adjust = {epoch: self.configs.learning_rate if epoch < 25 else self.configs.learning_rate * 0.1}
        elif self.configs.lradj == '6':
            lr_adjust = {epoch: self.configs.learning_rate if epoch < 5 else self.configs.learning_rate * 0.1}
        elif self.configs.lradj == 'TST':
            lr_adjust = {epoch: self.optimizer.learning_rate}  # Assuming this is how you access the learning rate

        if epoch in lr_adjust.keys():
            lr = lr_adjust[epoch]
            self.optimizer.learning_rate = ms.Tensor(lr, ms.float32)  # Update learning rate
            print(f'Updating learning rate to {lr:.6f}')

    def set_random_seed(self,seed):
        np.random.seed(seed)
        ms.set_seed(seed)
    def _get_data(self, flag):
            data_set, data_loader = get_numpy_data(self.configs, flag)
            return data_set, data_loader


    def train(self):
        # Load data
        if self.configs.use_GRAPH_MODE:
            context.set_context(mode=context.GRAPH_MODE)
        else:
            context.set_context(mode=context.PYNATIVE_MODE) 
        
        if self.configs.use_gpu and ms.context.get_context("device_target") == "GPU" :
            context.set_context(device_target="GPU")
            print("Using GPU for training.")
                
        else:
            context.set_context(device_target="CPU")
            print("Using CPU for training.")
        if self.configs.use_amp:
            context.set_context(enable_auto_mixed_precision=True)
        train_data, train_loader = self._get_data(flag='train')
        vali_data, vali_loader = self._get_data(flag='val')
        test_data, test_loader = self._get_data(flag='test')

        self.train_network.set_train()

        best_vali_loss = float('inf')  # Initialize best validation loss
        learning_rate = self.configs.learning_rate  # Initial learning rate

        # Initialize early stopping
        patience = self.configs.patience if hasattr(self.configs, 'patience') else 7  # Default patience is 7
        early_stopping = EarlyStopping(patience=patience, min_delta=0)

        # Create directory for saving models
        model_save_dir = self.configs.checkpoints  # Change the directory name to 'checkpoint'
        os.makedirs(model_save_dir, exist_ok=True)  # Create directory if it doesn't exist

        # Set context for mixed precision if enabled

           
            

        for epoch in range(self.configs.train_epochs):
            iter_count = 0
            train_loss_list = []  # Reset at the beginning of each epoch
            epoch_time = time.time()
            train_loss = 0
            batches = 0

            # Training phase
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
                iter_count += 1
                batches += 1
                # Convert to MindSpore Tensors
                batch_x = ms.Tensor(batch_x, ms.float32)
                batch_y = ms.Tensor(batch_y, ms.float32)

                # Compute loss
                loss = self.train_network(batch_x, batch_y)
                loss_value = loss.asnumpy()
                train_loss_list.append(loss_value)
                train_loss += loss_value

            avg_train_loss = train_loss / batches

            # Validation phase
            vali_loss = 0
            vali_batches = 0
            for j, (vali_x, vali_y, vali_x_mark, vali_y_mark) in enumerate(vali_loader):
                vali_batches += 1
                vali_x = ms.Tensor(vali_x, ms.float32)
                vali_y = ms.Tensor(vali_y, ms.float32)

                # Compute validation loss
                vali_loss_value = self.net_with_loss(vali_x, vali_y)
                vali_loss += vali_loss_value.asnumpy()

            avg_vali_loss = vali_loss / vali_batches

            # Test phase (optional)
            test_loss = 0
            test_batches = 0
            for k, (test_x, test_y, test_x_mark, test_y_mark) in enumerate(test_loader):
                test_batches += 1
                test_x = ms.Tensor(test_x, ms.float32)
                test_y = ms.Tensor(test_y, ms.float32)

                # Compute test loss
                test_loss_value = self.net_with_loss(test_x, test_y)
                test_loss += test_loss_value.asnumpy()

            avg_test_loss = test_loss / test_batches

            # Print epoch summary
            print(f'Epoch: {epoch + 1}, Steps: {batches} | '
                  f'Train Loss: {avg_train_loss:.7f} Vali Loss: {avg_vali_loss:.7f} Test Loss: {avg_test_loss:.7f}')
            self.adjust_learning_rate(epoch + 1)

            # Check for improvement
            if avg_vali_loss < best_vali_loss:
                print(f'Validation loss decreased ({best_vali_loss:.6f} --> {avg_vali_loss:.6f}). Saving model ...')
                best_vali_loss = avg_vali_loss
                # Save the model here, overwriting the previous one
                model_name = f"{self.configs.model}_{self.configs.data}_{self.configs.pred_len}_best_model.ckpt"  # 拼接 model 字符串
                model_path = os.path.join(model_save_dir, model_name)
                
                ms.save_checkpoint(self.train_network, model_path)
            else:
                print(f'Validation loss did not improve.')
            
            # Call early stopping
            if early_stopping(avg_vali_loss):
                break  # Exit the training loop

        print("Training complete.")




    def test(self):
        test_data,test_loader=self._get_data(flag='test')
        test_loss = 0
        test_batches = 0
        all_outputs = []
        all_labels = []

        for k, (test_x, test_y, test_x_mark, test_y_mark) in enumerate(test_loader):
            test_batches += 1
            test_x = ms.Tensor(test_x, ms.float32)
            test_y = ms.Tensor(test_y, ms.float32)

            # 计算测试损失
            test_loss_value = self.net_with_loss(test_x, test_y)
            test_loss += test_loss_value.asnumpy()

            # 记录输出和标签
            outputs = self.model(test_x)
            all_outputs.append(outputs.asnumpy())
            all_labels.append(test_y.asnumpy())

        # 计算平均测试损失
        avg_test_loss = test_loss / test_batches
        print(f'Average Test Loss (MSE): {avg_test_loss:.6f}')

        # 计算 MSE, RSE, MAE
        all_outputs = np.concatenate(all_outputs, axis=0)
        all_labels = np.concatenate(all_labels, axis=0)


        all_labels = all_labels[:, -self.configs.pred_len:, :]
        # 计算 MSE
        mse = np.mean((all_outputs - all_labels) ** 2)

        # 计算 RSE
        rse = np.sqrt(np.sum((all_outputs - all_labels) ** 2)) / np.sqrt(np.sum(all_labels ** 2))

        # 计算 MAE
        mae = np.mean(np.abs(all_outputs - all_labels))

        print(f'MSE: {mse:.6f}, RSE: {rse:.6f}, MAE: {mae:.6f}')  

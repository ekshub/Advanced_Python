import mindspore as ms
import numpy as np

from Exp_Main import Exp_Main


class Configs:
    def __init__(self):
        #请根据需要调整
        self.batch_size = 256
        self.root_path = './dataset/'
        self.data_path = 'ETTh1.csv'
        self.seq_len = 720
        self.pred_len = 96 
        self.enc_in = 7 
        self.period_len = 24 
        self.features = 'M'     
        self.data = 'ETTh1'
        self.freq = 'h'
        self.model = 'SparseTSF'
        self.target = 'OT'
        self.seed =2023
        self.learning_rate = 0.005
        self.patience = 5     
        self.train_epochs = 30
        
        self.use_GRAPH_MODE = False#在自己电脑用False,华为云可以用True
        
        self.use_gpu = True
        self.gpu = 0            #gpu
        
        #默认参数
        self.is_training = 1
        self.model_id = 'test'
        self.checkpoints = './checkpoints/'
        self.label_len = 48
        self.fc_dropout = 0.05    # fully connected dropout
        self.head_dropout = 0.0    # head dropout
        self.patch_len = 16       # patch length
        self.stride = 8           # stride
        self.padding_patch = 'end' # padding on the end
        self.revin = 1            # RevIN; True 1 False 0
        self.affine = 0           # RevIN-affine; True 1 False 0
        self.subtract_last = 0    # 0: subtract mean; 1: subtract last
        self.decomposition = 0     # decomposition; True 1 False 0
        self.kernel_size = 25      # decomposition-kernel
        self.individual = 0        # individual head; True 1 False 0
        self.embed_type = 0        # embedding type
        self.dec_in = 7            # decoder input size
        self.c_out = 7             # output size
        self.d_model = 512         # dimension of model
        self.n_heads = 8           # num of heads
        self.e_layers = 2          # num of encoder layers
        self.d_layers = 1          # num of decoder layers
        self.d_ff = 2048           # dimension of fcn
        self.moving_avg = 25       # window size of moving average
        self.factor = 1            # attn factor
        self.distil = True         # whether to use distilling in encoder
        self.dropout = 0.05        # dropout
        self.embed = 'learned'     # time features encoding
        self.activation = 'gelu'   # activation
        self.output_attention = False # whether to output attention in encoder
        self.do_predict = False     # whether to predict unseen future data
        self.num_workers = 10       # data loader num workers
        self.itr = 2                # experiments times
        self.des = 'test'           # exp description
        self.loss = 'mse'          # loss function
        self.lradj = 'type3'       # adjust learning rate
        self.pct_start = 0.3       # pct_start
        self.use_amp = False        # use automatic mixed precision training         
        self.use_multi_gpu = 0      # use multiple gpus
        self.devices = '0,1'        # device ids of multiple gpus
        self.test_flop = False       # See utils/tools for usage




def main():
            
            configs = Configs()
            np.random.seed(configs.seed)
            ms.set_seed(configs.seed)
            exp=Exp_Main(configs)

            print('>>>>>>>training : {}<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<')
            exp.train()
           

            print('>>>>>>>testing : {}<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<')
            exp.test()

          

if __name__ == "__main__":
    main()

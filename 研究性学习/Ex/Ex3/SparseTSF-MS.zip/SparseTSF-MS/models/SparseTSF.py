from mindspore import nn, ops
class SparseTSF(nn.Cell):
        def __init__(self, configs):
            super(SparseTSF, self).__init__()

            # 参数获取
            self.seq_len = configs.seq_len
            self.pred_len = configs.pred_len
            self.enc_in = configs.enc_in
            self.period_len = configs.period_len

            self.seg_num_x = self.seq_len // self.period_len
            self.seg_num_y = self.pred_len // self.period_len

            # 定义卷积层和线性层
            self.conv1d = nn.Conv1d(
                in_channels=1,
                out_channels=1,
                kernel_size=1 + 2 * (self.period_len // 2),
                stride=1,
                pad_mode="pad",
                padding=self.period_len // 2,
                has_bias=False
            )
            self.linear = nn.Dense(self.seg_num_x, self.seg_num_y, has_bias=False)

            # 定义操作符
            self.mean_op = ops.ReduceMean(keep_dims=True)
            self.transpose_op = ops.Transpose()
            self.reshape_op = ops.Reshape()
            self.add_op = ops.Add()
            self.sub_op = ops.Sub()

        def construct(self, x):
            batch_size = x.shape[0]

            # 计算序列的均值
            seq_mean = self.mean_op(x, 1)  # Shape: (batch_size, 1, enc_in)

            # 减去均值并转置维度
            x = self.sub_op(x, seq_mean)
            x = self.transpose_op(x, (0, 2, 1))  # Shape: (batch_size, enc_in, seq_len)

            # 调整形状并通过卷积层
            x = self.reshape_op(x, (-1, 1, self.seq_len))  # Shape: (batch_size * enc_in, 1, seq_len)
            x_conv = self.conv1d(x)  # (batch_size * enc_in, 1, seq_len)
            x_conv = self.reshape_op(x_conv, (-1, self.enc_in, self.seq_len))  # (batch_size, enc_in, seq_len)

            # 加上原始输入
            x_original = self.reshape_op(x, (-1, self.enc_in, self.seq_len))
            x = self.add_op(x_conv, x_original)

            # 调整形状并通过线性层
            x = self.reshape_op(x, (-1, self.seg_num_x, self.period_len))  # (batch_size * enc_in, seg_num_x, period_len)
            x = self.transpose_op(x, (0, 2, 1))  # (batch_size * enc_in, period_len, seg_num_x)
            y = self.linear(x)  # (batch_size * enc_in, period_len, seg_num_y)
            y = self.transpose_op(y, (0, 2, 1))  # (batch_size * enc_in, seg_num_y, period_len)
            y = self.reshape_op(y, (batch_size, self.enc_in, self.pred_len))  # (batch_size, enc_in, pred_len)
            y = self.transpose_op(y, (0, 2, 1))  # (batch_size, pred_len, enc_in)

            # 加上序列均值
            y = self.add_op(y, seq_mean)
            
            return y
class MyWithLossCell(nn.Cell):
        def __init__(self, backbone, loss_fn, configs):
            super(MyWithLossCell, self).__init__(auto_prefix=False)
            self.backbone = backbone
            self.loss_fn = loss_fn
            self.configs = configs
            self.pred_len=self.configs.pred_len
            self.features=self.configs.features

        def construct(self, data, label):
            outputs = self.backbone(data)
            f_dim = -1 if self.features == 'MS' else 0
            outputs = outputs[:, -self.pred_len:, f_dim:]
            label = label[:, -self.pred_len:, f_dim:]
            loss = self.loss_fn(outputs, label)
            return loss